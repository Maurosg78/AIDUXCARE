import{j as n}from"./ui-BUVpZRe7.js";function i({className:t,children:r,...e}){return n.jsx("button",{className:`inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors bg-primary text-primary-foreground hover:bg-primary/90 h-10 py-2 px-4 ${t||""}`,...e,children:r})}export{i as B};
//# sourceMappingURL=Button-ClwAeTUt.js.map
